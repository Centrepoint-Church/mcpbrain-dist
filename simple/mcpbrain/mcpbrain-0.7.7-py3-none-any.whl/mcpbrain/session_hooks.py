"""Cross-platform bodies for the `mcpbrain session-start` / `session-end` hooks.

session-start prints bounded priming context (recent hot.md + open actions) to
stdout; Claude Code injects it into the session. session-end reads the hook JSON
from stdin, parses the transcript, and queues a one-line session capture — but
only for substantial interactive sessions, so trivial/headless runs add no noise.
Neither ever hard-fails a session.
"""
from __future__ import annotations

import json
import sys
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

from mcpbrain import config, probes
from mcpbrain.capture import write_capture

_MAX_LINES = 8
_MIN_TURNS = 2          # at least this many user turns to count as "substantial"
_MIN_CHARS = 200        # ...or this much user text

# In-context recovery: each needs_action probe maps to one copy-pasteable remedy.
# Strings are kept here (single source) so they stay consistent with monitor.py.
# NOTE: `mcpbrain doctor` and `/mcpbrain-fix` are named as text only — this module
# must never import or call them. `mcpbrain auth` already exists in cli.py.
_REMEDIES: dict[str, str] = {
    "google": "Google sign-in expired → run: mcpbrain auth",
    "claude": "Daemon/plugin not seen recently → run: mcpbrain doctor",
    "clickup": "ClickUp key invalid → re-enter it in the mcpbrain wizard",
    "backup": "Backup overdue → run: mcpbrain doctor",
    "records": "Records repo problem → run: mcpbrain doctor",
    "enrichment": (
        "Enrichment stalled → open Claude so the hourly task can run, or run /mcpbrain-fix"
    ),
}

# Priority for the action-needed block: google, claude, then daemon/records, then the rest.
_REMEDY_PRIORITY: tuple[str, ...] = (
    "google",
    "claude",
    "records",
    "backup",
    "clickup",
    "enrichment",
)

_MAX_ACTIONS = 3


def session_start(home: str, out=None) -> None:
    out = out or sys.stdout
    print("## Recent continuity (hot.md)", file=out)
    try:
        hot = Path(config.records_dir(home)) / "state" / "hot.md"
        lines = [ln for ln in hot.read_text().splitlines()
                 if ln.startswith("- **20")][:_MAX_LINES]
        print("\n".join(lines) if lines else "(none)", file=out)
    except OSError:
        print("(none)", file=out)
    print("\n## Open actions", file=out)
    print(_open_actions(home), file=out)
    block = _action_needed(home)
    if block:
        print("\n" + block, file=out)


def _open_actions(home: str) -> str:
    try:
        port = (Path(home) / "control_port").read_text().strip()
        token = (Path(home) / "control_token").read_text().strip()
    except OSError:
        return "(actions unavailable)"
    req = urllib.request.Request(
        f"http://127.0.0.1:{port}/api/dashboard/today",
        headers={"Authorization": f"Bearer {token}"})
    try:
        with urllib.request.urlopen(req, timeout=3) as r:  # noqa: S310 loopback only
            data = json.loads(r.read() or b"{}")
    except Exception:  # noqa: BLE001 — daemon down / no dashboard
        return "(actions unavailable)"
    actions = (data or {}).get("actions", {}) or {}
    rows = []
    for bucket in ("overdue", "due_today", "upcoming"):
        for x in (actions.get(bucket) or []):
            t = (x.get("text") or "").strip().replace("\n", " ")
            if t:
                rows.append(f"- [{bucket}] {t[:80]}")
    return "\n".join(rows[:_MAX_LINES]) if rows else "(no open actions)"


def _action_needed(home: str) -> str:
    """Build the in-context recovery block: one remedy per needs_action probe.

    Returns the formatted block, or "" when nothing needs action. Never raises:
    if all_connections blows up, the caller still gets "" and the session is fine.
    not_started is deliberately ignored (mid-onboarding, not a regression).
    """
    try:
        conns = probes.all_connections(home, store=None) or {}
    except Exception:  # noqa: BLE001 — surfacing must never hard-fail the session
        return ""
    broken = [name for name, c in conns.items()
              if isinstance(c, dict) and c.get("state") == "needs_action"
              and name in _REMEDIES]

    def _rank(name: str) -> int:
        return _REMEDY_PRIORITY.index(name) if name in _REMEDY_PRIORITY else len(_REMEDY_PRIORITY)

    broken.sort(key=_rank)
    lines = [f"- {_REMEDIES[name]}" for name in broken[:_MAX_ACTIONS]]
    if not lines:
        return ""
    return "## ⚠️ Action needed\n" + "\n".join(lines)


def session_end(home: str, stdin=None) -> None:
    stdin = stdin or sys.stdin
    try:
        hook = json.loads(stdin.read() or "{}")
    except (ValueError, OSError):
        return
    tpath = hook.get("transcript_path") or ""
    if not tpath:
        return
    try:
        raw = Path(tpath).read_text()
    except OSError:
        return
    user_texts = []
    for line in raw.splitlines():
        try:
            ev = json.loads(line)
        except ValueError:
            continue
        msg = ev.get("message") or {}
        if msg.get("role") == "user":
            c = msg.get("content")
            if isinstance(c, str):
                user_texts.append(c)
            elif isinstance(c, list):
                user_texts.extend(b.get("text", "") for b in c if isinstance(b, dict))
    joined = " ".join(t.strip() for t in user_texts if t.strip())
    if len(user_texts) < _MIN_TURNS and len(joined) < _MIN_CHARS:
        return  # trivial / headless single-shot -> skip
    if not joined.strip():
        return  # no usable user text -> nothing to capture
    stamp = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    envelope = {
        "kind": "ingest",
        "source": "session_end_hook",
        "captured_at": stamp,
        "title": f"Session {hook.get('session_id', 'unknown')[:8]} {stamp[:10]}",
        "content": joined[:2000],
        "tags": "session",
        "observation_type": "note",
    }
    try:
        write_capture(home, envelope)
    except (ValueError, OSError):
        return


def session_start_main(argv=None) -> int:
    session_start(str(config.app_dir()))
    return 0


def session_end_main(argv=None) -> int:
    session_end(str(config.app_dir()))
    return 0

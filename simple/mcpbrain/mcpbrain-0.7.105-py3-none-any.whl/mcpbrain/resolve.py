"""Entity resolution: deterministic auto-merge + fuzzy candidate generation
+ write-time dedup cascade.

Step 1 (deterministic) merges same-type entities whose canonical keys match —
honorific-stripped, accent-folded, slugified. It is LLM-free and always safe to
run. Step 2 (blocking + scoring) surfaces near-duplicate candidate pairs for the
spool merge_review block in prepare; nothing is merged here.

Step 3 (write-time dedup, Q3): before inserting a new entity, check the
current in-memory index for a same-type near-duplicate above the high-confidence
threshold (_WRITE_TIME_MERGE_THRESHOLD). If found, redirect to the existing
entity instead of creating a duplicate. Behind config flag
`write_time_dedup_enabled` (default True as of Task 5.3). The cascade:
  exact canonical key → high-confidence token similarity → create new.
  Ambiguous band [_CANDIDATE_GATE, _WRITE_TIME_MERGE_THRESHOLD): still queued
  for LLM review via the existing spool merge_review mechanism.

Step 4 (email-equality merge, Task 5.3): a batch pass over EXISTING person
entities (_email_equality_merges), grouping by normalized email_addr rather
than name — catches duplicates whose names diverge too much for canonical-key
or token-similarity blocking (e.g. "Sam Lee" vs "Samuel Lee" sharing one
inbox). Also gated by `write_time_dedup_enabled`; logs merges with
method="email" so they're distinguishable from the name-based tiers in
entity_merge_log.

Note: embedding-based semantic blocking (cosine similarity on entity vectors)
would give better recall for non-overlapping names (e.g. "Joel" vs "J. Chelliah")
but requires entity-specific vector indices that don't yet exist. The token-
similarity cascade handles the common fragmentation patterns. Deferred.

The LLM-adjudication tier (_adjudicate / _pick_winner) has been removed in §9A.
Fuzzy candidate generation (_candidate_pairs) is preserved for
prepare._merge_review_block.
"""

import logging

from mcpbrain import config
from mcpbrain.chunking import slugify, _canonical_name

log = logging.getLogger(__name__)


# Shared/role mailbox local-parts. A person's identity must NEVER be keyed on one
# of these: multiple DISTINCT people send from office@/info@/hello@ (a church runs
# shared inboxes heavily), and email-equality dedup would irreversibly collapse them
# into one entity. Kept broad; extend as new shared aliases appear.
_ROLE_LOCAL_PARTS = frozenset({
    "info", "hello", "hi", "hey", "support", "admin", "team", "contact", "contactus",
    "enquiries", "enquiry", "office", "mail", "email", "noreply", "no-reply",
    "donotreply", "do-not-reply", "notifications", "newsletter", "accounts",
    "billing", "hr", "jobs", "careers", "sales", "help", "helpdesk", "service",
    "feedback", "events", "media", "press", "marketing", "giving", "prayer",
    "kids", "youth", "reception", "general", "all", "everyone", "staff",
})


def is_role_address(email: str) -> bool:
    """True when an email is a shared/role mailbox (its local-part is a role token),
    not a personal address. Such addresses must not key person-identity merges."""
    email = (email or "").strip().lower()
    if "@" not in email:
        return False
    local = email.split("@", 1)[0].split("+", 1)[0]  # drop +tags
    return local in _ROLE_LOCAL_PARTS


def canonical_key(name: str) -> str:
    """Normalised dedup key: honorific-stripped + accent-folded + slugified.

    'Ps Joel' and 'Joel' share a key; 'Chané' and 'Chane' share a key.
    """
    return slugify(_canonical_name(name))


# Types whose IDENTITY is their name — safe to merge on canonical name. Everything
# else (document, thread, topic, meeting, event, group, facility, system, unknown…)
# is identified by its source id or is too generic to merge on title: distinct such
# nodes routinely share titles ("Untitled document", "TEST", "Budget") and merging
# them on canonical key collapsed ~3,980 entities on the real corpus. Allowlist, so a
# new/unrecognised type is never name-merged by default (fail-safe).
_NAME_MERGEABLE_TYPES = frozenset({"person", "org", "project"})


def _origin_map(store) -> dict:
    """id -> origin ('local'|'org'). Queried here (not via entities_for_resolution)
    to keep the frozen store surface untouched, per the B4a guard scope."""
    with store._connect() as db:
        return {r["id"]: (r["origin"] or "local")
                for r in db.execute("SELECT id, origin FROM entities").fetchall()}


def _org_survivor(members, origins):
    """B4a rule 2: whenever a group contains at least one org row, an org row
    must survive — never a local one (the import would otherwise resurrect the
    org node with local flesh stranded). This applies UNIVERSALLY, including
    during the curator's own dedup pass: curator=True only controls whether
    org<->org groups are merged at all (rule 1) — it must never also disable
    who survives once a merge happens (rule 2), since a curator install is a
    normal member machine too and can have its own local duplicates collide
    with an org row in the same canonical-key/email group. When 2+ org rows
    are present (only reachable when curator=True, since a non-curator group
    with org_count>=2 is skipped upstream by the org<->org guard), the
    highest-mentions org row wins — a local row never outranks any org row.
    Returns the forced survivor, or None when the group is purely local."""
    org_members = [m for m in members if origins.get(m["id"]) == "org"]
    if not org_members:
        return None
    return max(org_members, key=lambda m: (m.get("mentions", 0), len(m["name"]), m["id"]))


def _emit_merge_candidates(store, members, origins, home=None) -> None:
    """A local pass found two ORG rows it thinks are duplicates. Local must not
    merge them (the next import would resurrect them); instead contribute the
    pair upstream as a merge-candidate signal for the curator (spec B4a rule 1).
    Best-effort: no fleet pin configured, or any error, means this silently
    no-ops — a missing signal must never break local resolution.

    home must be the SAME home the caller resolved (threaded through, not
    re-derived): a caller for a non-default store/home must never silently
    fall back to reading a different machine's live fleet-pin config to
    decide whether to emit."""
    try:
        import json
        from mcpbrain import config as _config
        from mcpbrain.org_contracts import ContributionRecord, source_ref
        home = str(home) if home is not None else str(_config.app_dir())
        pin = _config.fleet_pin(home)
        if not pin.is_pinned:
            return
        org_ids = sorted(m["id"] for m in members if origins.get(m["id"]) == "org")
        email = _config.owner_email(home)
        for i in range(len(org_ids)):
            for j in range(i + 1, len(org_ids)):
                claim = {"kind": "merge_candidate", "a": org_ids[i], "b": org_ids[j]}
                rec = ContributionRecord(
                    claim=claim, confidence=0.5, valid_from="",
                    contributor_email=email, source_kind="local",
                    source_ref=source_ref(pin.fleet_secret, f"{org_ids[i]}|{org_ids[j]}"))
                with store._connect() as db:
                    db.execute("INSERT INTO org_contrib_outbox(record) VALUES(?)",
                               (json.dumps(rec.to_dict(), sort_keys=True),))
    except Exception:  # noqa: BLE001 — a best-effort signal must never break resolution
        log.debug("resolve: merge-candidate emit failed", exc_info=True)


def _deterministic_merges(store, *, home=None, curator: bool = False) -> int:
    """Merge same-type, canonical-key-identical entities into the highest-mentions
    survivor. Returns the number of merges applied. Safe (no LLM).

    Only name-identity types (_NAME_MERGEABLE_TYPES) are merged on canonical name;
    structural/artifact types are keyed by source id, not title, so they are never
    name-merged here (they would collide catastrophically on generic titles).

    B4a cross-layer guard: unless curator=True, a group with 2+ org-origin rows
    is never merged locally (that's the curator's job on the org layer — a local
    merge would just be resurrected by the next import); a group with any org
    row always forces that org row (highest-mentions org row, if several) to
    survive, unconditionally — rule 2 does not depend on curator (see
    _org_survivor)."""
    ents = store.entities_for_resolution()
    origins = _origin_map(store)
    groups = {}   # (type, canonical_key) -> [entity dicts]
    for e in ents:
        if e["type"] not in _NAME_MERGEABLE_TYPES:
            continue
        key = canonical_key(e["name"])
        if not key:
            continue
        groups.setdefault((e["type"], key), []).append(e)
    merged = 0
    for (_type, _key), members in groups.items():
        if len(members) < 2:
            continue
        org_count = sum(1 for m in members if origins.get(m["id"]) == "org")
        if not curator and org_count >= 2:
            _emit_merge_candidates(store, members, origins, home=home)   # B4a rule 1
            continue
        # id is the final tiebreaker so equal-mentions, equal-name-length groups
        # pick a deterministic survivor. entities_for_resolution() ORDERs BY id, so
        # group membership order is stable too, making the whole merge reproducible.
        survivor = (_org_survivor(members, origins)
                    or max(members, key=lambda m: (m.get("mentions", 0), len(m["name"]), m["id"])))
        for m in members:
            if m["id"] != survivor["id"]:
                store.merge_entities(m["id"], survivor["id"], method="deterministic")
                merged += 1
    return merged


def _email_equality_merges(store, home=None, *, curator: bool = False) -> int:
    """Merge person entities that share a normalized email_addr into the
    highest-mentions survivor. Returns the number of merges applied.

    A THIRD dedup mechanism (Task 5.3), separate from _deterministic_merges
    (canonical-name-key) and write_time_dedup_check (write-time token-similarity
    redirect for NEW entities). This one is a batch pass over EXISTING entities,
    grouping by email_addr rather than name — catches genuine duplicates whose
    names diverge too much for canonical-key or token-similarity blocking to see
    (e.g. "Sam Lee" vs "Samuel Lee") but who share an email inbox.

    Gated behind config.write_time_dedup_enabled (same flag as the write-time
    cascade): reuses it rather than adding a new switch, per the plan.

    Query is self-contained (not entities_for_resolution(), which doesn't expose
    email_addr) — deliberately scoped to this module per the task's file list.

    B4a cross-layer guard: same org<->org rule as _deterministic_merges — unless
    curator=True, a group with 2+ org-origin rows is skipped (contributed
    upstream instead); a group with any org row always forces that org row to
    survive, unconditionally — rule 2 does not depend on curator (see
    _org_survivor).
    """
    home_str = str(home) if home is not None else str(config.app_dir())
    if not config.write_time_dedup_enabled(home_str):
        return 0
    origins = _origin_map(store)
    with store._connect() as conn:
        rows = conn.execute(
            "SELECT id, name, email_addr, mentions FROM entities "
            "WHERE type='person' AND COALESCE(email_addr,'') != '' ORDER BY id"
        ).fetchall()
    groups = {}   # normalized email -> [entity dicts]
    for r in rows:
        email = r["email_addr"].strip().lower()
        if not email:
            continue
        groups.setdefault(email, []).append(dict(r))
    merged = 0
    for _email, members in groups.items():
        if len(members) < 2:
            continue
        if is_role_address(_email):
            continue  # shared/role inbox — distinct people, never identity-merge (C1)
        org_count = sum(1 for m in members if origins.get(m["id"]) == "org")
        if not curator and org_count >= 2:
            _emit_merge_candidates(store, members, origins, home=home)   # B4a rule 1
            continue
        survivor = (_org_survivor(members, origins)
                    or max(members, key=lambda m: (m.get("mentions", 0), len(m["name"]), m["id"])))
        for m in members:
            if m["id"] != survivor["id"]:
                store.merge_entities(m["id"], survivor["id"], method="email")
                merged += 1
    return merged


# --- R6: blocking + fuzzy candidate scoring -------------------------------

_STOPWORDS = {"the", "a", "an", "of", "and", "for", "to", "in", "at", "on"}
# Jaccard floor for a fuzzy candidate: ~at least 1 shared token out of 3 distinct.
# Below this, pairs aren't worth LLM adjudication; above, they go to the
# adjudicator (R7), never auto-merge.
_CANDIDATE_GATE = 0.3


def _tokens(name) -> set:
    """Lowercased, accent-folded, honorific-stripped alphanumeric tokens; drop
    stopwords and 1-char tokens."""
    key = canonical_key(name)            # 'joel-chelliah'
    toks = {t for t in key.split("-") if len(t) > 1 and t not in _STOPWORDS}
    return toks


def _token_set_ratio(a: set, b: set) -> float:
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)


def _candidate_pairs(entities) -> list:
    """Return (a, b) entity-dict pairs that are: same NAME-IDENTITY type, share a
    significant token, token-set similarity >= gate, and NOT canonical-key-identical
    (those are handled deterministically). No cross-type pairs, no singletons.

    Only _NAME_MERGEABLE_TYPES (person/org/project) are considered (#4): structural
    types (document/thread/topic/meeting/…) are identified by their source id, not
    their title, so pairing them explodes the candidate count (365k on the live
    store) AND feeds pairs the merge appliers' type guard rejects anyway — the same
    allowlist enforced in _deterministic_merges (#23) and apply_duplicate_verdicts."""
    by_type = {}
    for e in entities:
        if e["type"] not in _NAME_MERGEABLE_TYPES:
            continue
        by_type.setdefault(e["type"], []).append(e)
    pairs = []
    seen = set()
    for _type, members in by_type.items():
        # index by token for blocking
        index = {}
        toks_cache = {}
        for e in members:
            toks_cache[e["id"]] = _tokens(e["name"])
            for t in toks_cache[e["id"]]:
                index.setdefault(t, []).append(e)
        for _tok, bucket in index.items():
            for i in range(len(bucket)):
                for j in range(i + 1, len(bucket)):
                    a, b = bucket[i], bucket[j]
                    if a["id"] == b["id"]:
                        continue
                    pair_key = tuple(sorted((a["id"], b["id"])))
                    if pair_key in seen:
                        continue
                    seen.add(pair_key)   # dedup on first encounter, regardless of outcome
                    if canonical_key(a["name"]) == canonical_key(b["name"]):
                        continue   # deterministic handles these
                    if _token_set_ratio(toks_cache[a["id"]], toks_cache[b["id"]]) >= _CANDIDATE_GATE:
                        pairs.append((a, b))
    return pairs


def _pick_winner(a, b):
    """Survivor is the higher-mentions entity; tiebreak longer name, then id.
    Returns (winner, loser). Used by drain._apply_merge_answers for spool merges."""
    winner = max((a, b), key=lambda m: (m.get("mentions", 0), len(m["name"]), m["id"]))
    loser = b if winner is a else a
    return winner, loser


# --- Q3: write-time dedup cascade -----------------------------------------

# Token-set similarity above this threshold → auto-merge at write time without
# LLM review. Conservative: 0.8 means ≥4 out of 5 tokens must overlap (or a
# 2-token name where both match). Lower values risk false positives.
_WRITE_TIME_MERGE_THRESHOLD = 0.8


def build_entity_index(entities: list[dict]) -> dict:
    """Build a BLOCKED index for write-time dedup lookups.

    Returns {"ids": {id: {name,type,key,toks}}, "by_key": {(type,key): id},
    "by_tok": {(type,tok): set(ids)}}. by_key gives O(1) exact-canonical matches;
    by_tok lets write_time_dedup_check scan only entities that SHARE A TOKEN with
    the candidate (blocking) instead of all N — important on a 25k+ entity graph.
    add_to_index keeps it current for intra-batch dedup within one apply() run.
    """
    index: dict = {"ids": {}, "by_key": {}, "by_tok": {}}
    for e in entities:
        add_to_index(index, e["id"], e["name"], e["type"])
    return index


def add_to_index(index: dict, eid: str, name: str, entity_type: str) -> None:
    """Insert one entity into a build_entity_index() structure.

    Called as new entities are created during an apply() run so later entities in
    the same batch dedup against them, not only against the store snapshot.
    """
    key = canonical_key(name)
    toks = _tokens(name)
    index["ids"][eid] = {"name": name, "type": entity_type, "key": key, "toks": toks}
    if key:
        index["by_key"].setdefault((entity_type, key), eid)
    for t in toks:
        index["by_tok"].setdefault((entity_type, t), set()).add(eid)


def write_time_dedup_check(name: str, entity_type: str,
                           index: dict) -> str | None:
    """Return the id of an existing entity to redirect this write to, or None.

    Cascade (same type only), using the blocked index:
    1. Exact canonical key → certain duplicate → redirect.
    2. Among candidates SHARING A TOKEN, token-set ratio >=
       _WRITE_TIME_MERGE_THRESHOLD → high-confidence duplicate → redirect.
    3. Otherwise → None (caller creates a new entity).

    The ambiguous band [_CANDIDATE_GATE, threshold) is NOT acted on here; those
    pairs go to the spool merge_review mechanism in prepare. Embedding-based
    blocking (cosine on entity vectors) would additionally catch non-overlapping
    aliases ('Joel' vs 'J. Chelliah') but needs entity vectors that don't exist
    yet — deferred (tracked on #10).
    """
    if not name or not index:
        return None
    key = canonical_key(name)
    if key:
        hit = index["by_key"].get((entity_type, key))
        if hit:
            return hit
    toks = _tokens(name)
    if not toks:
        return None
    candidates: set = set()
    for t in toks:
        candidates |= index["by_tok"].get((entity_type, t), set())
    for eid in candidates:
        ent = index["ids"].get(eid)
        if ent and _token_set_ratio(toks, ent["toks"]) >= _WRITE_TIME_MERGE_THRESHOLD:
            return eid
    return None


def resolve_entities(store, client=None, *, max_adjudications: int = 200, home=None,
                     curator: bool = False) -> dict:
    """Resolve duplicate entities (deterministic tier only; §9A).

    The LLM-adjudication tier is removed — spool merge_review handles it. Fuzzy
    candidate generation (_candidate_pairs) is preserved for prepare._merge_review_block.

    Runs _deterministic_merges (canonical-name-key) first, then
    _email_equality_merges (Task 5.3) — email merging can still catch entities
    that survived name-based merging as distinct (different names, same inbox).
    Both counts are summed into auto_merges.

    curator=True is the B4a bypass: only org_curate.run (dedupping the org layer
    itself) should pass it. Local (curator=False, the default) callers never
    merge two org-origin rows into each other.
    """
    auto = _deterministic_merges(store, home=home, curator=curator)
    auto += _email_equality_merges(store, home=home, curator=curator)
    return {"mode": "deterministic", "auto_merges": auto, "llm_merges": 0,
            "llm_calls": 0, "kept_distinct": 0}
